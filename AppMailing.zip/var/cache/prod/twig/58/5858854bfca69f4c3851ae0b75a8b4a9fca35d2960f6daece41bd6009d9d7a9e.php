<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_1b2edf15a5c0bde441a313e4548eab11b459a14df0090d57b7239d933eeac78b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_645ab5e184fd375a207e9c9891baeb68e1fed3cb0bbeb390a4f8abd757b88a21 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_645ab5e184fd375a207e9c9891baeb68e1fed3cb0bbeb390a4f8abd757b88a21->enter($__internal_645ab5e184fd375a207e9c9891baeb68e1fed3cb0bbeb390a4f8abd757b88a21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_645ab5e184fd375a207e9c9891baeb68e1fed3cb0bbeb390a4f8abd757b88a21->leave($__internal_645ab5e184fd375a207e9c9891baeb68e1fed3cb0bbeb390a4f8abd757b88a21_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_65d83530d34e17fc7f8ebc192f9a5bf2fee36570ddc2ce42bdb8f87039c593d8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_65d83530d34e17fc7f8ebc192f9a5bf2fee36570ddc2ce42bdb8f87039c593d8->enter($__internal_65d83530d34e17fc7f8ebc192f9a5bf2fee36570ddc2ce42bdb8f87039c593d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_65d83530d34e17fc7f8ebc192f9a5bf2fee36570ddc2ce42bdb8f87039c593d8->leave($__internal_65d83530d34e17fc7f8ebc192f9a5bf2fee36570ddc2ce42bdb8f87039c593d8_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_ae1ad5663678d0e3c1ac7f5d04fb7cce9175aad49c1eb5ef80f33b1c1d83b929 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae1ad5663678d0e3c1ac7f5d04fb7cce9175aad49c1eb5ef80f33b1c1d83b929->enter($__internal_ae1ad5663678d0e3c1ac7f5d04fb7cce9175aad49c1eb5ef80f33b1c1d83b929_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_ae1ad5663678d0e3c1ac7f5d04fb7cce9175aad49c1eb5ef80f33b1c1d83b929->leave($__internal_ae1ad5663678d0e3c1ac7f5d04fb7cce9175aad49c1eb5ef80f33b1c1d83b929_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_e29647ddc0eddf7e02c862532e3082ff40c20b05b53481a8c5e4f04e9f8453bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e29647ddc0eddf7e02c862532e3082ff40c20b05b53481a8c5e4f04e9f8453bd->enter($__internal_e29647ddc0eddf7e02c862532e3082ff40c20b05b53481a8c5e4f04e9f8453bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_e29647ddc0eddf7e02c862532e3082ff40c20b05b53481a8c5e4f04e9f8453bd->leave($__internal_e29647ddc0eddf7e02c862532e3082ff40c20b05b53481a8c5e4f04e9f8453bd_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "C:\\wamp64\\www\\projects\\AptanaWorkspace\\AppMailing\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception_full.html.twig");
    }
}
